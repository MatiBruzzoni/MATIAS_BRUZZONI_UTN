#Ejercicio 5
x2=input("Ingrese Cualquier numero =")
print(f"Has introducido {x2}:")
