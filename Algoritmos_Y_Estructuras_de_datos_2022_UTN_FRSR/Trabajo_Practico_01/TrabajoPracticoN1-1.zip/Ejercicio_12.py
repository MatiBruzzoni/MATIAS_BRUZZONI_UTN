#ejercicio 12
x22=input("ingrese una palabra = ")

contador=0

for i in x22:
        contador+=1

print("en total tiene",contador,"letras")