#Ejercio10
x19=int(input("ingrese un numero ="))
x20=int(input("ingrese otro numero ="))
if x19==x20:
        print("los 2 numeros son iguales")
elif x19 > x20:
    print(f"el numero {x19} es mayor que {x20}:")
else:
    print(f"el numero {x20} es mayor que {x19}:")