#Ejercicio 4
y=input("Ingrese un numero entero =")
w=input("Ingrese otro numero entero =")
print(w,y)