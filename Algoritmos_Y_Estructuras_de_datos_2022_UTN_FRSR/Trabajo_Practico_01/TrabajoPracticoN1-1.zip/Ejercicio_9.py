#Ejercicio 9 

x17=int(input("ingrese un numero ="))
x18=int(input("ingrese otro numero ="))
if x17==x18:
    print("iguales")
else:
    print("No son iguales")