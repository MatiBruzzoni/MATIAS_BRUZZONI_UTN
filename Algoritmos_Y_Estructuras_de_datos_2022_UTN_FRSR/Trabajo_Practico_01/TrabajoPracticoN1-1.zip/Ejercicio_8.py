#Ejercicio 8
x15=float(input("ingrese un numero real ="))
x16=float(input("ingrese otro numero real ="))
div3=x15/x16
myroundnumber= round(div3,2)
print(myroundnumber)