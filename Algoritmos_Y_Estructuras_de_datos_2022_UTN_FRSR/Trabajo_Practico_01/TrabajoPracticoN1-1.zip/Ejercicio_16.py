#Ejercicio 16
x26=int(input("ingrese un numero ="))
if (x26>0):
    print("el numero es positivo")
elif (x26<0):
        print("el numero ingresado es negativo")
else:
        print("el numero es igual a 0")  