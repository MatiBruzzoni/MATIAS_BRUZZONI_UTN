#Ejercicio 2
n=input("Ingrese un numero =")
print(n)
