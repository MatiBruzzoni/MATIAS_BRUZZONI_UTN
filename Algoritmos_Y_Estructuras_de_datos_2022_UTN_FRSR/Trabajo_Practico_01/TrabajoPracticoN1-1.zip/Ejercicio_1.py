#Ejercicio 1
print("hola mundo")
