dolar=float(input("Ingrese el monto de la transaccion en dolares: "))
pesos= 200*dolar
print("La cotizacion del dolar el dia de hoy es de 200 Pesos por Dolar")
print(f"El valor de la transaccion en pesos es {pesos}")
print(f"El total de la transaccion con la comision del banco es {pesos*1.04}")