#ejercicio 15
x24=input("ingrese una palabra =")
x25=input("ingrese otra palabra =")
ww=(len(x24))
wwe=(len(x25))
if ww==wwe:
    print("tiene la misma longitud")
elif ww>wwe:
        print(f"la palabra {x24} es mayor que {x25}")
else: 
        print(f"la palabra {x25} es mayor que {x24}:")  