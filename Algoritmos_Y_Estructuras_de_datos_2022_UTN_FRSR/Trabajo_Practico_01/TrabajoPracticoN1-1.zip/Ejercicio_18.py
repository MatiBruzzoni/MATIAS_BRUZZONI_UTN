#ejercicio 18
A=int(input("digite el primer numero ="))
B=int(input("digite el segundo numero ="))
C=int(input("digite el tercer numero ="))

if(A>B and B>C):
                print("",A,"-",B,"-",C)
elif(B>A and A>C):
                print("",B,"-",A,"-",C) 
elif(C>A and A>B): 
                print("",C,"-",A,"-",B) 
elif(C>B and B>A):
                print("",C,"-",B,"-",A)                
elif(A>C and C>B): 
                print("",A,"-",C,"-",B) 
elif(B>C and C>A):                
              print("",B,"-",C,"-",A)
else:
    print("se ingresaron numeros iguales")       
