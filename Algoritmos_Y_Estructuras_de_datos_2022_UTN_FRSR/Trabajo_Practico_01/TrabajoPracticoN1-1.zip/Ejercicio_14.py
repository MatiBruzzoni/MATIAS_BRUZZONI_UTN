#ejercicio 14
x23=float(input("ingrese un numero real ="))
print (abs(x23))
