
#Ejercicio 7

#a)
x5=int(input("ingrese un valor para a ="))
x6=int(input("ingrese un valor para b ="))
suma2= 5*x5 + 10*x6
print(f"El resultado de 5a + 10b es = {suma2}:")

#b)
x7=int(input("Ingrese un valor para b ="))
alcuadrado= x7**2
print(f"El resultado de b2 es = {alcuadrado}:")

#c)
x8=int(input("ingrese un valor para n ="))
x9=int(input("ingrese un valor para n2 ="))
div= (2*x8)-1/(2*x9)+1
print(f"El resultado de 2n-1/2n+1 es = {div}: ")

#d)
x10=int(input("ingrese un valor, a este se le sacara la raiz al cuadrado del mismo ="))
import math
print (math.sqrt(x10))

#e)
x11=int(input("ingrese un valor para x ="))
x12=int(input("ingrese un valor para y ="))
operacion= 2*x11-x12
print(f"el Resultado de 2x-y es = {operacion}:")

#f)
x13=int (input("ingrese un valor para x ="))
x14=int (input("ingrese un valor para y ="))
div2= x13-x14/x13+x14
print(f"El resultado de x-y/x+y es = {div2}:")