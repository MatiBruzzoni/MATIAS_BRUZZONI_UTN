 #Ejercicio 17
x27=int(input("ingrese un numero ="))
x28=int(input("ingrese otro numero ="))
if x27==x28:
        print("los 2 numeros son iguales")
elif x27 > x28:
    print(f"el numero {x27} es mayor que {x28}:")
else:
    print(f"el numero {x28} es mayor que {x27}:")