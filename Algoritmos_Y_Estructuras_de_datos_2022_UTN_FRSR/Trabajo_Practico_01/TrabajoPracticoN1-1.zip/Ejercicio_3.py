#Ejercicio 3
nombre=input("Ingrese su nombre =")
apellido=input(f"ingrese su apellido,{nombre}:")
print(f"Bienvenido,{nombre} {apellido}:")
