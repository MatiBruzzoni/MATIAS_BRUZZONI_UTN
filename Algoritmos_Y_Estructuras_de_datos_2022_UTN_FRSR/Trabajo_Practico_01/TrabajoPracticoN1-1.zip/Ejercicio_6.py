#Ejercicio 6
x3=int (input("Ingrese un valor numerico ="))
x4=int (input("Ingrese un segundo valor numerico ="))
suma = x3 + x4
resta= x3 - x4
multiplicacion= x3*x4
division= x3/x4
print (suma)
print (resta)
print (multiplicacion)
print (division)